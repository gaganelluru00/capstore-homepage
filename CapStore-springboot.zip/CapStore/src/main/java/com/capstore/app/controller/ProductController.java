package com.capstore.app.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.app.model.Product;
import com.capstore.app.service.ProductServiceImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200", allowedHeaders = "*")
@RequestMapping("/merchant")
public class ProductController {

	@Autowired
	ProductServiceImpl productServiceImpl;
	
	
	//All Products Data
	@GetMapping(value="/allProducts")
	public List<Product> getAllProducts(){
		return productServiceImpl.allProductsList();
	}
	
	
	//Products data of particular category
	@GetMapping(value="/productCategory/{category}")
	public List<Product> getCategory(@PathVariable("category") String productCategory){
		
		return productServiceImpl.specificCategoryProducts(productCategory);
	}
	
	
	//Product data based on discount
	@GetMapping(value="/discountCategory/{category}/{discountPercent}")
	public List<Product> getDiscountProducts(@PathVariable("category") String productCategory,@PathVariable("discountPercent") String discount){
		
		return productServiceImpl.specificDiscountProducts(productCategory, discount);
	}
	
	
	@GetMapping(value="/searchProducts/{category}")
	public List<Product> getSearchProducts(@PathVariable("category") String productSearch){
		return productServiceImpl.searchProducts(productSearch);
	}
	
	
	
	
	
}
